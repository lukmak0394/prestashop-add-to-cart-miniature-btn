# prestashop-add-to-cart-miniature-btn
Prestashop module adding "add to cart button" to product miniature

# Functionalities
1. Allows to add only one product to cart from miniature. After adding product it's getting inactive
2. It's inactive for products where quantity = 0 and that needs customization / have multiple variants

# Preview


![presentation](https://user-images.githubusercontent.com/58666224/178230097-f8883f23-c6de-458e-82de-eff0af98b532.JPG)
